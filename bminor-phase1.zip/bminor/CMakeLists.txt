cmake_minimum_required(VERSION 3.10)
project(bminor_phase1 CXX)
set(CMAKE_CXX_STANDARD 17)
set(CMAKE_CXX_STANDARD_REQUIRED ON)
if(NOT CMAKE_BUILD_TYPE)
  set(CMAKE_BUILD_TYPE Release)
endif()

add_library(bminor_core
  src/diagnostics.cpp src/token.cpp src/lexer.cpp src/ast.cpp src/parser.cpp src/highlighter.cpp)
target_include_directories(bminor_core PUBLIC src)
target_compile_options(bminor_core PRIVATE -Wall -Wextra -Wpedantic)

add_executable(bminor src/main.cpp)
target_link_libraries(bminor bminor_core)

enable_testing()
add_executable(unit_tests tests/unit_tests.cpp)
target_link_libraries(unit_tests bminor_core)
add_test(NAME unit COMMAND unit_tests)
add_test(NAME e2e COMMAND bash ${CMAKE_SOURCE_DIR}/tests/run_tests.sh $<TARGET_FILE:bminor>
         WORKING_DIRECTORY ${CMAKE_SOURCE_DIR})
