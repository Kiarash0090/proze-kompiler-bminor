# B-Minor front end, Phase 1: lexer, parser, AST, syntax highlighter

C++17, standard library only.

## Build and run

```
make              # builds ./bminor        (or: cmake -B build && cmake --build build)
make test         # unit tests + end-to-end tests

./bminor tests/valid/functions.bm                 # ANSI-coloured source on the terminal
./bminor prog.bm --html out.html                  # standalone HTML/CSS page
./bminor prog.bm --tokens                         # token stream: line:col, kind, lexeme
./bminor prog.bm --ast                            # abstract syntax tree with locations
./bminor prog.bm --no-highlight                   # only diagnostics
```

Diagnostics go to stderr as `file:line:col: error: message`. Exit status: 0 = ok, 1 = lexical/syntax
errors (output is still produced), 2 = usage or I/O error.

## Layout

```
src/        common.h diagnostics.cpp token.* lexer.* ast.* parser.* highlighter.* main.cpp
tests/      unit_tests.cpp  run_tests.sh  valid/*.bm  invalid/*.bm
docs/       lexical-spec.md  grammar.md  design.md  sample-highlight.html
```

## Where each grading item lives

| Item | Where |
|---|---|
| Lexer (maximal munch, priority, lexeme + position, whitespace, comments) | `src/lexer.cpp`, `docs/lexical-spec.md` |
| Formal token definitions | `docs/lexical-spec.md` sections 1 and 2 |
| Grammar (EBNF), LL(1)/LL(2) analysis, left-recursion removal | `docs/grammar.md`, `src/parser.cpp` |
| AST with locations and a type field | `src/ast.h`, `src/parser.cpp` |
| Error handling and panic-mode recovery | `docs/lexical-spec.md` section 3, `docs/grammar.md` section 6 |
| AST-based syntax highlighting | `src/highlighter.cpp`, `docs/design.md` |
| ANSI and HTML/CSS output | `Highlighter::renderAnsi`, `Highlighter::renderHtml` |
| Modularity, documentation, tests | `docs/design.md`, `tests/` |
