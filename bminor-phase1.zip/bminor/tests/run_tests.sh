#!/usr/bin/env bash
# End-to-end tests. Valid programs must give exit 0 and no diagnostics.
# Invalid programs must give exit 1 (a crash would give 134/139), report the
# text on their "// EXPECT:" line, and exactly the "// ERRORS:" number of errors if present.
BIN=${1:-./bminor}
cd "$(dirname "$0")/.." || exit 2
fail=0

for f in tests/valid/*.bm; do
    out=$("$BIN" "$f" --no-highlight 2>&1); rc=$?
    if [ $rc -ne 0 ] || [ -n "$out" ]; then
        echo "FAIL  $f (exit $rc)"; echo "$out" | sed 's/^/      /'; fail=1
    else
        echo "ok    $f"
    fi
done

for f in tests/invalid/*.bm; do
    expect=$(sed -n '1s#^// EXPECT: ##p' "$f")
    count=$(sed -n '2s#^// ERRORS: ##p' "$f")
    out=$("$BIN" "$f" --no-highlight 2>&1); rc=$?
    n=$(grep -c ': error: ' <<<"$out")
    if [ $rc -ne 1 ]; then
        echo "FAIL  $f (exit $rc, expected 1)"; fail=1
    elif ! grep -qF -- "$expect" <<<"$out"; then
        echo "FAIL  $f (missing message: $expect)"; echo "$out" | sed 's/^/      /'; fail=1
    elif [ -n "$count" ] && [ "$n" -ne "$count" ]; then
        echo "FAIL  $f (expected $count errors, got $n)"; echo "$out" | sed 's/^/      /'; fail=1
    else
        echo "ok    $f"
    fi
done

[ $fail -eq 0 ] && echo "All end-to-end tests passed." || echo "Some end-to-end tests FAILED."
exit $fail
