// Minimal dependency-free unit tests for the lexer, parser and highlighter.
#include <iostream>
#include <string>
#include <vector>

#include "ast.h"
#include "highlighter.h"
#include "lexer.h"
#include "parser.h"

static int g_total = 0, g_failed = 0;
#define CHECK(cond)                                                              \
    do {                                                                         \
        ++g_total;                                                               \
        if (!(cond)) {                                                           \
            ++g_failed;                                                          \
            std::cerr << __FILE__ << ':' << __LINE__ << ": CHECK failed: " #cond "\n"; \
        }                                                                        \
    } while (0)

using K = TokenKind;
using N = NodeKind;

// ---- helpers ---------------------------------------------------------------

static std::vector<K> kinds(const std::vector<Token>& t, bool withComments = false) {
    std::vector<K> out;
    for (const auto& tok : t) {
        if (tok.kind == K::END_OF_FILE) continue;
        if (tok.kind == K::COMMENT && !withComments) continue;
        out.push_back(tok.kind);
    }
    return out;
}

static std::vector<Token> lex(const std::string& src, DiagnosticSink& d) { return Lexer(src, d).tokenize(); }

struct Parsed {
    std::string src;
    DiagnosticSink diag{"test"};
    std::vector<Token> toks;
    NodePtr tree;
    explicit Parsed(const std::string& s) : src(s) {
        toks = Lexer(src, diag).tokenize();
        tree = Parser(toks, diag).parseProgram();
    }
    // First statement of main's body, for expression tests.
    const Node& firstStmt() const { return *tree->kids[0]->kids[2]->kids[0]; }
};

static Parsed inMain(const std::string& body) { return Parsed("main: function void () = { " + body + " }"); }

static const Node* find(const Node& n, N kind, const std::string& text = "") {
    if (n.kind == kind && (text.empty() || n.text == text)) return &n;
    for (const auto& k : n.kids)
        if (const Node* r = find(*k, kind, text)) return r;
    return nullptr;
}

static std::string stripAnsi(const std::string& s) {
    std::string out;
    for (size_t i = 0; i < s.size(); ++i) {
        if (s[i] == '\x1b') {
            while (i < s.size() && s[i] != 'm') ++i;
        } else out += s[i];
    }
    return out;
}

// ---- lexer -----------------------------------------------------------------

static void testKeywordPriority() {
    DiagnosticSink d("t");
    auto t = lex("return returnx _x1 integer If", d);
    CHECK((kinds(t) == std::vector<K>{K::KW_RETURN, K::IDENT, K::IDENT, K::KW_INTEGER, K::IDENT}));
    CHECK(d.count() == 0);
}

static void testMaximalMunch() {
    DiagnosticSink d("t");
    auto t = lex("<= < == = ++ + -- - != ! && ||", d);
    CHECK((kinds(t) == std::vector<K>{K::LE, K::LT, K::EQ, K::ASSIGN, K::INC, K::PLUS, K::DEC, K::MINUS,
                                      K::NE, K::NOT, K::AND, K::OR}));
    DiagnosticSink d2("t");
    CHECK((kinds(lex("a+++b", d2)) == std::vector<K>{K::IDENT, K::INC, K::PLUS, K::IDENT}));
    CHECK((kinds(lex("x<=y", d2)) == std::vector<K>{K::IDENT, K::LE, K::IDENT}));
    CHECK((kinds(lex("12abc", d2)) == std::vector<K>{K::INT_LIT, K::IDENT}));
    CHECK(d2.count() == 0);
}

static void testCommentsAndPositions() {
    DiagnosticSink d("t");
    auto t = lex("a // c\n b /* x\ny */ c", d);
    CHECK((kinds(t, true) == std::vector<K>{K::IDENT, K::COMMENT, K::IDENT, K::COMMENT, K::IDENT}));
    CHECK(t[2].loc.line == 2 && t[2].loc.col == 2);
    CHECK(t[4].lexeme == "c" && t[4].loc.line == 3 && t[4].loc.col == 6);
    CHECK(t[3].lexeme == "/* x\ny */");
    CHECK(d.count() == 0);
    // division is not a comment
    DiagnosticSink d2("t");
    CHECK((kinds(lex("a / b", d2)) == std::vector<K>{K::IDENT, K::SLASH, K::IDENT}));
}

static void testLiterals() {
    DiagnosticSink d("t");
    auto t = lex(R"("hi\n\"x\"" 'a' '\n' '\0x41' 123 true false)", d);
    CHECK((kinds(t) == std::vector<K>{K::STRING_LIT, K::CHAR_LIT, K::CHAR_LIT, K::CHAR_LIT, K::INT_LIT,
                                      K::KW_TRUE, K::KW_FALSE}));
    CHECK(t[0].lexeme == R"("hi\n\"x\"")");
    CHECK(d.count() == 0);
}

static void testLexicalErrorsDoNotStop() {
    {
        DiagnosticSink d("t");
        auto t = lex("x: string = \"abc\ny: integer;", d);
        CHECK(d.count() == 1);
        CHECK(d.all()[0].message == "unterminated string literal");
        CHECK(kinds(t).back() == K::SEMI);                    // scanning resumed on the next line
        CHECK(t[4].kind == K::INVALID && t[5].lexeme == "y");
    }
    {
        DiagnosticSink d("t");
        auto t = lex("a /* never ends", d);
        CHECK(d.count() == 1 && d.all()[0].message == "unterminated block comment");
        CHECK(t[1].kind == K::INVALID);
    }
    {
        DiagnosticSink d("t");
        CHECK((kinds(lex("a @ b", d)) == std::vector<K>{K::IDENT, K::INVALID, K::IDENT}));
        CHECK(d.count() == 1 && d.all()[0].loc.col == 3);
    }
    {
        DiagnosticSink d("t");
        lex("a & b | c", d);
        CHECK(d.count() == 2);
    }
    {
        DiagnosticSink d("t");
        lex("99999999999999999999 9223372036854775808 9223372036854775809", d);
        CHECK(d.count() == 2);  // first and third are out of range
    }
    {
        DiagnosticSink d("t");
        auto t = lex("'' 'ab' 'x", d);
        CHECK(d.count() == 3);
        CHECK(t[0].kind == K::INVALID && t[1].kind == K::INVALID && t[2].kind == K::INVALID);
    }
    {
        DiagnosticSink d("t");
        auto t = lex("caf\xC3\xA9 x", d);  // non-ASCII is one invalid token, not several
        CHECK(d.count() == 1);
        CHECK(kinds(t).size() == 3);
    }
}

static void testPositions() {
    DiagnosticSink d("t");
    auto t = lex("x: integer;\n  y", d);
    CHECK(t[0].loc.line == 1 && t[0].loc.col == 1);
    CHECK(t[1].loc.col == 2);
    CHECK(t[2].loc.col == 4);
    CHECK(t[4].loc.line == 2 && t[4].loc.col == 3);
    CHECK(t[4].offset == 14);
    DiagnosticSink d2("t");
    auto crlf = lex("a\r\nb", d2);
    CHECK(crlf[1].loc.line == 2 && crlf[1].loc.col == 1);
}

// ---- parser ----------------------------------------------------------------

static void testPrecedence() {
    auto p = inMain("a = b + c * d ^ e ^ f;");
    CHECK(p.diag.count() == 0);
    const Node& assign = *p.firstStmt().kids[0];
    CHECK(assign.kind == N::AssignExpr);
    const Node& plus = *assign.kids[1];
    CHECK(plus.kind == N::BinaryExpr && plus.text == "+");
    const Node& mul = *plus.kids[1];
    CHECK(mul.text == "*");
    const Node& pow1 = *mul.kids[1];
    CHECK(pow1.text == "^" && pow1.kids[1]->text == "^");  // a^(b^c): right associative

    auto q = inMain("x = a - b - c;");
    const Node& top = *q.firstStmt().kids[0]->kids[1];
    CHECK(top.text == "-" && top.kids[0]->kind == N::BinaryExpr && top.kids[1]->kind == N::Identifier);

    auto r = inMain("x = a || b && c == d;");
    const Node& orN = *r.firstStmt().kids[0]->kids[1];
    CHECK(orN.text == "||" && orN.kids[1]->text == "&&" && orN.kids[1]->kids[1]->text == "==");

    auto s = inMain("a = b = 1;");  // right associative assignment
    CHECK(s.firstStmt().kids[0]->kids[1]->kind == N::AssignExpr);

    auto u = inMain("x = -a ^ 2;");  // unary binds tighter than ^
    CHECK(u.firstStmt().kids[0]->kids[1]->text == "^" && u.firstStmt().kids[0]->kids[1]->kids[0]->kind == N::UnaryExpr);
}

static void testDanglingElse() {
    auto p = inMain("if (a) if (b) x = 1; else x = 2;");
    CHECK(p.diag.count() == 0);
    const Node& outer = p.firstStmt();
    CHECK(outer.kind == N::IfStmt && outer.kids.size() == 2);
    CHECK(outer.kids[1]->kind == N::IfStmt && outer.kids[1]->kids.size() == 3);
}

static void testDeclarationsAndTypes() {
    Parsed p("a: array [3] integer = {1, 2, 3};\nf: function integer (x: integer, v: array [] char);\n");
    CHECK(p.diag.count() == 0);
    CHECK(p.tree->kids.size() == 2);
    const Node& a = *p.tree->kids[0];
    CHECK(a.kind == N::VarDecl && a.text == "a" && a.kids[0]->kind == N::ArrayType);
    CHECK(a.kids[1]->kind == N::ArrayInit && a.kids[1]->kids.size() == 3);
    const Node& f = *p.tree->kids[1];
    CHECK(f.kind == N::FuncDecl && f.kids.size() == 2);  // prototype: no body
    CHECK(f.kids[1]->kids.size() == 2 && f.kids[1]->kids[1]->kids[0]->kind == N::ArrayType);
    CHECK(f.typeAnn.empty());  // filled by the semantic phase
}

static void testNodeLocations() {
    Parsed p("x: integer = 1;\nmain: function void () = {\n    y = f(2);\n}\n");
    CHECK(p.diag.count() == 0);
    CHECK(p.tree->kids[1]->loc.line == 2 && p.tree->kids[1]->loc.col == 1);
    const Node* call = find(*p.tree, N::CallExpr);
    CHECK(call && call->loc.line == 3 && call->loc.col == 9);
    const Node* assign = find(*p.tree, N::AssignExpr);
    CHECK(assign && assign->loc.line == 3 && assign->loc.col == 5);
}

static void testErrorRecovery() {
    {
        Parsed p("x: integer = ;\ny: integer = 3;\nz: integer = 4\nw: integer = 5;\n");
        CHECK(p.diag.count() == 2);
        CHECK(find(*p.tree, N::VarDecl, "y") != nullptr);  // parsing continued
        CHECK(find(*p.tree, N::VarDecl, "w") != nullptr);
    }
    {
        auto p = inMain("x = ; y = 1; return;");
        CHECK(p.diag.count() == 1);
        CHECK(find(*p.tree, N::ReturnStmt) != nullptr);
    }
    {
        auto p = inMain("if (a { x = 1; } y = 2;");  // missing ')' : braces skipped as a unit
        CHECK(p.diag.count() == 1);
        CHECK(find(*p.tree, N::AssignExpr) != nullptr);
    }
    {
        auto p = inMain("1 = 2;");
        CHECK(p.diag.count() == 1);
    }
    {
        Parsed p("f: function integer () = { return 1;");  // EOF inside block
        CHECK(p.diag.count() == 1);
        CHECK(find(*p.tree, N::ReturnStmt) != nullptr);
    }
    for (const char* junk : {"}}} ))) ;;; 123 456 if else for {", "f: function", ":::", "if", "x: array [", "\"", "{{{{",
                             "x: integer = {1, 2", "for(;;", "f(1,", ""}) {
        Parsed p(junk);  // must terminate and never crash
        CHECK(p.tree != nullptr);
        CHECK(std::string(junk).empty() || p.diag.count() > 0);
    }
}

static void testInvalidTokensAreNotReportedTwice() {
    Parsed p("x: integer = 5 @;\n");
    CHECK(p.diag.count() == 1);  // only the lexical error; the parser skipped the INVALID token
}

// ---- highlighter -----------------------------------------------------------

static void testHighlighterContextual() {
    Parsed p("f: function integer (n: integer) = { v: integer = n; return f(v); }\n");
    CHECK(p.diag.count() == 0);
    Highlighter hl(p.src, p.toks, *p.tree);
    auto cat = [&](const std::string& lexeme, int nth) {
        int seen = 0;
        for (size_t i = 0; i < p.toks.size(); ++i)
            if (p.toks[i].lexeme == lexeme && seen++ == nth) return hl.categoryOf(i);
        return Category::Plain;
    };
    CHECK(cat("f", 0) == Category::FuncDecl);
    CHECK(cat("f", 1) == Category::FuncCall);   // same spelling, different role
    CHECK(cat("n", 0) == Category::Param);
    CHECK(cat("n", 1) == Category::Variable);
    CHECK(cat("v", 0) == Category::VarDecl);
    CHECK(cat("v", 1) == Category::Variable);   // a variable, not a call
    CHECK(cat("integer", 0) == Category::TypeName);
    CHECK(cat("return", 0) == Category::Keyword);
}

static void testHighlighterRoundTrip() {
    for (const char* src : {"main: function integer () = {\n  print \"hi\\n\"; /* c\n omment */ return 0; // x\n}\n",
                            "x: integer = 5 @ # ;\ns: string = \"open\n/* unterminated", "", "   \n\t  "}) {
        Parsed p(src);
        Highlighter hl(p.src, p.toks, *p.tree);
        CHECK(stripAnsi(hl.renderAnsi()) == src);  // colouring never alters the program text
    }
}

static void testHtml() {
    Parsed p("main: function void () = { f(1 < 2); /* a & b */ }\n");
    Highlighter hl(p.src, p.toks, *p.tree);
    std::string html = hl.renderHtml("t");
    CHECK(html.find("<pre>") != std::string::npos);
    CHECK(html.find("<span class=\"kw\">function</span>") != std::string::npos);
    CHECK(html.find("<span class=\"fn-call\">f</span>") != std::string::npos);
    CHECK(html.find("<span class=\"lit num\">1</span>") != std::string::npos);
    CHECK(html.find("&lt;") != std::string::npos && html.find("&amp;") != std::string::npos);
    CHECK(html.find("<script") == std::string::npos);  // no JavaScript needed
}

int main() {
    testKeywordPriority();
    testMaximalMunch();
    testCommentsAndPositions();
    testLiterals();
    testLexicalErrorsDoNotStop();
    testPositions();
    testPrecedence();
    testDanglingElse();
    testDeclarationsAndTypes();
    testNodeLocations();
    testErrorRecovery();
    testInvalidTokensAreNotReportedTwice();
    testHighlighterContextual();
    testHighlighterRoundTrip();
    testHtml();
    std::cout << (g_total - g_failed) << '/' << g_total << " checks passed\n";
    return g_failed == 0 ? 0 : 1;
}
