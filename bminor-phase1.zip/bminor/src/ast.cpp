#include "ast.h"

#include <ostream>

const char* nodeKindName(NodeKind k) {
    switch (k) {
        case NodeKind::Program: return "Program";
        case NodeKind::VarDecl: return "VarDecl";
        case NodeKind::FuncDecl: return "FuncDecl";
        case NodeKind::ParamList: return "ParamList";
        case NodeKind::Param: return "Param";
        case NodeKind::TypeSpec: return "TypeSpec";
        case NodeKind::ArrayType: return "ArrayType";
        case NodeKind::Block: return "Block";
        case NodeKind::ExprStmt: return "ExprStmt";
        case NodeKind::ReturnStmt: return "ReturnStmt";
        case NodeKind::PrintStmt: return "PrintStmt";
        case NodeKind::IfStmt: return "IfStmt";
        case NodeKind::ForStmt: return "ForStmt";
        case NodeKind::Empty: return "Empty";
        case NodeKind::AssignExpr: return "AssignExpr";
        case NodeKind::BinaryExpr: return "BinaryExpr";
        case NodeKind::UnaryExpr: return "UnaryExpr";
        case NodeKind::PostfixExpr: return "PostfixExpr";
        case NodeKind::CallExpr: return "CallExpr";
        case NodeKind::IndexExpr: return "IndexExpr";
        case NodeKind::Identifier: return "Identifier";
        case NodeKind::IntLiteral: return "IntLiteral";
        case NodeKind::CharLiteral: return "CharLiteral";
        case NodeKind::StringLiteral: return "StringLiteral";
        case NodeKind::BoolLiteral: return "BoolLiteral";
        case NodeKind::ArrayInit: return "ArrayInit";
        case NodeKind::ErrorNode: return "ErrorNode";
    }
    return "?";
}

void dumpAst(const Node& n, std::ostream& os, int depth) {
    os << std::string(static_cast<size_t>(depth) * 2, ' ') << nodeKindName(n.kind);
    if (!n.text.empty()) os << " '" << n.text << "'";
    os << " @" << n.loc.line << ':' << n.loc.col;
    if (!n.typeAnn.empty()) os << " : " << n.typeAnn;
    os << '\n';
    for (const auto& k : n.kids) dumpAst(*k, os, depth + 1);
}
