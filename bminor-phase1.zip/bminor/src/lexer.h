// lexer.h - hand-written DFA-style scanner for B-Minor.
#pragma once
#include <string>
#include <vector>

#include "common.h"
#include "token.h"

// Converts source text into tokens. Whitespace is skipped; comments are kept
// as COMMENT tokens (the parser ignores them, the highlighter prints them).
// The lexer never throws and never stops: bad input yields INVALID tokens plus
// a diagnostic, and scanning resumes right after the offending text.
class Lexer {
public:
    Lexer(const std::string& source, DiagnosticSink& diag) : src_(source), diag_(diag) {}

    // Returns all tokens; the last one is always END_OF_FILE.
    std::vector<Token> tokenize();

private:
    const std::string& src_;
    DiagnosticSink& diag_;
    size_t pos_ = 0;
    int line_ = 1;
    int col_ = 1;

    bool eof() const { return pos_ >= src_.size(); }
    char peek(size_t ahead = 0) const { return pos_ + ahead < src_.size() ? src_[pos_ + ahead] : '\0'; }
    bool atEol() const { return peek() == '\n' || (peek() == '\r' && peek(1) == '\n'); }
    char advance();
    SourceLoc here() const { return {line_, col_}; }
    Token make(TokenKind kind, size_t start, SourceLoc loc) const;

    void skipWhitespace();
    Token next();
    Token scanWord(size_t start, SourceLoc loc);
    Token scanNumber(size_t start, SourceLoc loc);
    Token scanString(size_t start, SourceLoc loc);
    Token scanChar(size_t start, SourceLoc loc);
    Token scanLineComment(size_t start, SourceLoc loc);
    Token scanBlockComment(size_t start, SourceLoc loc);
    Token scanInvalid(size_t start, SourceLoc loc);
    bool scanEscape();
    Token oneOrTwo(size_t start, SourceLoc loc, char second, TokenKind two, TokenKind one);
};
