#include "parser.h"

#include <algorithm>

namespace {

// Binary operator precedence levels, lowest first. All are left-associative.
const std::vector<std::vector<TokenKind>> kBinaryLevels = {
    {TokenKind::OR},
    {TokenKind::AND},
    {TokenKind::LT, TokenKind::LE, TokenKind::GT, TokenKind::GE, TokenKind::EQ, TokenKind::NE},
    {TokenKind::PLUS, TokenKind::MINUS},
    {TokenKind::STAR, TokenKind::SLASH, TokenKind::PERCENT},
};

bool oneOf(TokenKind k, const std::vector<TokenKind>& set) {
    return std::find(set.begin(), set.end(), k) != set.end();
}

}  // namespace

Parser::Parser(const std::vector<Token>& tokens, DiagnosticSink& diag) : all_(tokens), diag_(diag) {
    for (size_t i = 0; i < all_.size(); ++i)
        if (all_[i].kind != TokenKind::COMMENT) idx_.push_back(i);
}

// ---------------------------------------------------------------- helpers

const Token& Parser::at(size_t ahead) const { return all_[idx_[std::min(p_ + ahead, idx_.size() - 1)]]; }

size_t Parser::advance() {
    size_t i = idx_[p_];
    if (cur().kind != TokenKind::END_OF_FILE) ++p_;
    return i;
}

bool Parser::match(TokenKind k) {
    if (cur().kind != k) return false;
    advance();
    return true;
}

std::string Parser::describe(const Token& t) const {
    if (t.kind == TokenKind::END_OF_FILE) return "end of file";
    std::string s = t.lexeme.size() > 20 ? t.lexeme.substr(0, 20) + "..." : t.lexeme;
    return "'" + s + "'";
}

void Parser::report(const std::string& msg, SourceLoc loc) { diag_.error(loc, msg); }

// An INVALID token has already been reported by the lexer. Failing on it still
// triggers recovery, but a second message about the same spot would only add noise.
void Parser::fail(const std::string& msg) {
    if (cur().kind != TokenKind::INVALID) report(msg, cur().loc);
    throw ParseError{};
}

size_t Parser::expect(TokenKind k, const std::string& what) {
    if (cur().kind == k) return advance();
    fail("expected " + what + ", found " + describe(cur()));
}

NodePtr Parser::node(NodeKind k, size_t tok, std::string text) {
    auto n = std::make_unique<Node>();
    n->kind = k;
    n->tok = static_cast<int>(tok);
    n->loc = all_[tok].loc;
    n->text = std::move(text);
    return n;
}

// ---------------------------------------------------------------- program

NodePtr Parser::parseProgram() {
    auto prog = node(NodeKind::Program, idx_[0]);
    prog->loc = {1, 1};
    while (cur().kind != TokenKind::END_OF_FILE) {
        size_t start = p_;
        try {
            prog->add(parseDecl());
        } catch (const ParseError&) {
            prog->add(node(NodeKind::ErrorNode, idx_[start], "syntax error"));
            syncTopLevel(start);
        }
    }
    return prog;
}

// decl ::= IDENT ':' ( function-rest | type [ '=' initializer ] ';' )
NodePtr Parser::parseDecl() {
    if (cur().kind != TokenKind::IDENT)
        fail("expected a declaration of the form 'name: type', found " + describe(cur()));
    size_t nameTok = advance();
    expect(TokenKind::COLON, "':' after the declared name");
    if (cur().kind == TokenKind::KW_FUNCTION) return parseFunctionRest(nameTok);

    auto decl = node(NodeKind::VarDecl, nameTok, all_[nameTok].lexeme);
    decl->add(parseType());
    if (match(TokenKind::ASSIGN)) decl->add(cur().kind == TokenKind::LBRACE ? parseArrayInit() : parseExpr());
    expect(TokenKind::SEMI, "';' after declaration");
    return decl;
}

// function-rest ::= 'function' type '(' [ param { ',' param } ] ')' ( '=' block | ';' )
NodePtr Parser::parseFunctionRest(size_t nameTok) {
    advance();  // 'function'
    auto fn = node(NodeKind::FuncDecl, nameTok, all_[nameTok].lexeme);
    fn->add(parseType());
    size_t lp = expect(TokenKind::LPAREN, "'(' after the function's return type");
    auto params = node(NodeKind::ParamList, lp);
    if (cur().kind != TokenKind::RPAREN) {
        do {
            params->add(parseParam());
        } while (match(TokenKind::COMMA));
    }
    expect(TokenKind::RPAREN, "')' after the parameter list");
    fn->add(std::move(params));
    if (match(TokenKind::ASSIGN)) {
        if (cur().kind != TokenKind::LBRACE)
            fail("expected '{' to start the function body, found " + describe(cur()));
        fn->add(parseBlock());
    } else {
        expect(TokenKind::SEMI, "'=' followed by a body, or ';' for a prototype");
    }
    return fn;
}

NodePtr Parser::parseParam() {
    if (cur().kind != TokenKind::IDENT) fail("expected a parameter name, found " + describe(cur()));
    size_t nameTok = advance();
    expect(TokenKind::COLON, "':' after the parameter name");
    auto p = node(NodeKind::Param, nameTok, all_[nameTok].lexeme);
    p->add(parseType());
    return p;
}

// type ::= 'integer' | 'boolean' | 'char' | 'string' | 'void' | 'auto'
//        | 'array' '[' [ expr ] ']' type
NodePtr Parser::parseType() {
    switch (cur().kind) {
        case TokenKind::KW_INTEGER:
        case TokenKind::KW_BOOLEAN:
        case TokenKind::KW_CHAR:
        case TokenKind::KW_STRING:
        case TokenKind::KW_VOID:
        case TokenKind::KW_AUTO: {
            size_t t = advance();
            return node(NodeKind::TypeSpec, t, all_[t].lexeme);
        }
        case TokenKind::KW_ARRAY: {
            size_t t = advance();
            auto arr = node(NodeKind::ArrayType, t, "array");
            expect(TokenKind::LBRACKET, "'[' after 'array'");
            NodePtr size;
            if (cur().kind != TokenKind::RBRACKET) size = parseExpr();
            expect(TokenKind::RBRACKET, "']' in array type");
            arr->add(parseType());
            if (size) arr->add(std::move(size));
            return arr;
        }
        default:
            fail("expected a type (integer, boolean, char, string, void, auto or array), found " +
                 describe(cur()));
    }
}

// initializer-list ::= '{' element { ',' element } '}'   element ::= expr | initializer-list
NodePtr Parser::parseArrayInit() {
    size_t lb = advance();  // '{'
    auto init = node(NodeKind::ArrayInit, lb);
    do {
        init->add(cur().kind == TokenKind::LBRACE ? parseArrayInit() : parseExpr());
    } while (match(TokenKind::COMMA));
    expect(TokenKind::RBRACE, "'}' to close the array initializer");
    return init;
}

// ---------------------------------------------------------------- statements

NodePtr Parser::parseBlock() {
    size_t lb = expect(TokenKind::LBRACE, "'{'");
    auto blk = node(NodeKind::Block, lb);
    while (cur().kind != TokenKind::RBRACE && cur().kind != TokenKind::END_OF_FILE)
        blk->add(parseStmtSafe());
    if (cur().kind == TokenKind::RBRACE)
        advance();
    else
        report("expected '}' to close the block opened at line " + std::to_string(all_[lb].loc.line) +
                   ", found end of file",
               cur().loc);
    return blk;
}

// Parses one statement; on a syntax error resynchronises and returns an ErrorNode.
NodePtr Parser::parseStmtSafe() {
    size_t start = p_;
    try {
        return parseStmt();
    } catch (const ParseError&) {
        syncStmt(start);
        return node(NodeKind::ErrorNode, idx_[start], "syntax error");
    }
}

NodePtr Parser::parseStmt() {
    switch (cur().kind) {
        case TokenKind::LBRACE:
            return parseBlock();
        case TokenKind::KW_IF:
            return parseIf();
        case TokenKind::KW_FOR:
            return parseFor();
        case TokenKind::KW_RETURN: {
            auto r = node(NodeKind::ReturnStmt, advance());
            if (cur().kind != TokenKind::SEMI) r->add(parseExpr());
            expect(TokenKind::SEMI, "';' after return statement");
            return r;
        }
        case TokenKind::KW_PRINT: {
            auto p = node(NodeKind::PrintStmt, advance());
            if (cur().kind != TokenKind::SEMI) {
                do {
                    p->add(parseExpr());
                } while (match(TokenKind::COMMA));
            }
            expect(TokenKind::SEMI, "';' after print statement");
            return p;
        }
        case TokenKind::KW_WHILE:
            fail("'while' loops are not part of B-Minor; use 'for'");
        case TokenKind::KW_ELSE:
            fail("'else' without a matching 'if'");
        default:
            break;
    }
    if (cur().kind == TokenKind::IDENT && at(1).kind == TokenKind::COLON) return parseDecl();  // LL(2)

    auto stmt = node(NodeKind::ExprStmt, idx_[p_]);
    stmt->add(parseExpr());
    expect(TokenKind::SEMI, "';' after expression");
    return stmt;
}

// if ::= 'if' '(' expr ')' stmt [ 'else' stmt ]
// The 'else' is consumed greedily, so it binds to the nearest 'if'.
NodePtr Parser::parseIf() {
    auto n = node(NodeKind::IfStmt, advance());
    expect(TokenKind::LPAREN, "'(' after 'if'");
    n->add(parseExpr());
    expect(TokenKind::RPAREN, "')' after the condition");
    n->add(parseStmtSafe());
    if (match(TokenKind::KW_ELSE)) n->add(parseStmtSafe());
    return n;
}

// for ::= 'for' '(' [expr] ';' [expr] ';' [expr] ')' stmt
NodePtr Parser::parseFor() {
    auto n = node(NodeKind::ForStmt, advance());
    expect(TokenKind::LPAREN, "'(' after 'for'");
    n->add(parseOptionalExpr(TokenKind::SEMI));
    expect(TokenKind::SEMI, "';' after the for-loop initialiser");
    n->add(parseOptionalExpr(TokenKind::SEMI));
    expect(TokenKind::SEMI, "';' after the for-loop condition");
    n->add(parseOptionalExpr(TokenKind::RPAREN));
    expect(TokenKind::RPAREN, "')' after the for-loop header");
    n->add(parseStmtSafe());
    return n;
}

NodePtr Parser::parseOptionalExpr(TokenKind terminator) {
    if (cur().kind == terminator) return node(NodeKind::Empty, idx_[p_]);
    return parseExpr();
}

// ---------------------------------------------------------------- expressions
//
//   expr    ::= or [ '=' expr ]                       (right-associative)
//   or      ::= and { '||' and }                      one loop per binary level:
//   and     ::= cmp { '&&' cmp }                      EBNF repetition instead of
//   cmp     ::= add { ('<'|'<='|'>'|'>='|'=='|'!=') add }   left recursion
//   add     ::= mul { ('+'|'-') mul }
//   mul     ::= exp { ('*'|'/'|'%') exp }
//   exp     ::= unary [ '^' exp ]                     (right-associative)
//   unary   ::= ('-'|'!') unary | postfix
//   postfix ::= primary { '[' expr ']' | '(' [args] ')' | '++' | '--' }

NodePtr Parser::parseExpr() { return parseAssign(); }

NodePtr Parser::parseAssign() {
    NodePtr lhs = parseBinary(0);
    if (cur().kind != TokenKind::ASSIGN) return lhs;
    size_t op = advance();
    if (lhs->kind != NodeKind::Identifier && lhs->kind != NodeKind::IndexExpr)
        report("left side of '=' is not assignable", lhs->loc);
    auto n = node(NodeKind::AssignExpr, op, "=");
    n->loc = lhs->loc;
    n->add(std::move(lhs));
    n->add(parseAssign());
    return n;
}

NodePtr Parser::parseBinary(size_t level) {
    if (level == kBinaryLevels.size()) return parseExponent();
    NodePtr lhs = parseBinary(level + 1);
    while (oneOf(cur().kind, kBinaryLevels[level])) {
        size_t op = advance();
        auto n = node(NodeKind::BinaryExpr, op, all_[op].lexeme);
        n->loc = lhs->loc;
        n->add(std::move(lhs));
        n->add(parseBinary(level + 1));
        lhs = std::move(n);
    }
    return lhs;
}

NodePtr Parser::parseExponent() {
    NodePtr base = parseUnary();
    if (cur().kind != TokenKind::CARET) return base;
    size_t op = advance();
    auto n = node(NodeKind::BinaryExpr, op, "^");
    n->loc = base->loc;
    n->add(std::move(base));
    n->add(parseExponent());
    return n;
}

NodePtr Parser::parseUnary() {
    if (cur().kind == TokenKind::MINUS || cur().kind == TokenKind::NOT) {
        size_t op = advance();
        auto n = node(NodeKind::UnaryExpr, op, all_[op].lexeme);
        n->add(parseUnary());
        return n;
    }
    return parsePostfix();
}

NodePtr Parser::parsePostfix() {
    NodePtr e = parsePrimary();
    while (true) {
        if (cur().kind == TokenKind::LBRACKET) {
            size_t lb = advance();
            auto n = node(NodeKind::IndexExpr, lb);
            n->loc = e->loc;
            n->add(std::move(e));
            n->add(parseExpr());
            expect(TokenKind::RBRACKET, "']' after the array index");
            e = std::move(n);
        } else if (cur().kind == TokenKind::LPAREN) {
            size_t lp = advance();
            if (e->kind != NodeKind::Identifier) report("only a function name can be called", e->loc);
            auto n = node(NodeKind::CallExpr, lp);
            n->loc = e->loc;
            n->add(std::move(e));
            if (cur().kind != TokenKind::RPAREN) {
                do {
                    n->add(parseExpr());
                } while (match(TokenKind::COMMA));
            }
            expect(TokenKind::RPAREN, "')' after the call arguments");
            e = std::move(n);
        } else if (cur().kind == TokenKind::INC || cur().kind == TokenKind::DEC) {
            size_t op = advance();
            auto n = node(NodeKind::PostfixExpr, op, all_[op].lexeme);
            n->loc = e->loc;
            n->add(std::move(e));
            e = std::move(n);
        } else {
            return e;
        }
    }
}

NodePtr Parser::parsePrimary() {
    switch (cur().kind) {
        case TokenKind::INT_LIT: {
            size_t t = advance();
            return node(NodeKind::IntLiteral, t, all_[t].lexeme);
        }
        case TokenKind::CHAR_LIT: {
            size_t t = advance();
            return node(NodeKind::CharLiteral, t, all_[t].lexeme);
        }
        case TokenKind::STRING_LIT: {
            size_t t = advance();
            return node(NodeKind::StringLiteral, t, all_[t].lexeme);
        }
        case TokenKind::KW_TRUE:
        case TokenKind::KW_FALSE: {
            size_t t = advance();
            return node(NodeKind::BoolLiteral, t, all_[t].lexeme);
        }
        case TokenKind::IDENT: {
            size_t t = advance();
            return node(NodeKind::Identifier, t, all_[t].lexeme);
        }
        case TokenKind::LPAREN: {
            advance();
            NodePtr e = parseExpr();
            expect(TokenKind::RPAREN, "')' to close the parenthesised expression");
            return e;
        }
        default:
            fail("expected an expression, found " + describe(cur()));
    }
}

// ---------------------------------------------------------------- recovery

// Panic mode inside a block. Skips to just after the next ';', to the '}' that
// closes the current block (not consumed), or to a token that starts a new
// statement. Balanced { } groups met on the way are skipped as a unit.
void Parser::syncStmt(size_t start) {
    if (p_ == start) advance();  // guarantee progress
    int depth = 0;
    while (cur().kind != TokenKind::END_OF_FILE) {
        switch (cur().kind) {
            case TokenKind::LBRACE:
                ++depth;
                break;
            case TokenKind::RBRACE:
                if (depth == 0) return;
                if (--depth == 0) {
                    advance();
                    return;
                }
                break;
            case TokenKind::SEMI:
                if (depth == 0) {
                    advance();
                    return;
                }
                break;
            case TokenKind::KW_IF:
            case TokenKind::KW_FOR:
            case TokenKind::KW_RETURN:
            case TokenKind::KW_PRINT:
                if (depth == 0) return;
                break;
            case TokenKind::IDENT:
                if (depth == 0 && at(1).kind == TokenKind::COLON) return;  // next declaration
                break;
            default:
                break;
        }
        advance();
    }
}

// Panic mode at file level: skip to just after the ';' or the '}' that ends
// the broken declaration, or to the start of the next declaration (IDENT ':').
void Parser::syncTopLevel(size_t start) {
    if (p_ == start) advance();  // guarantee progress
    int depth = 0;
    while (cur().kind != TokenKind::END_OF_FILE) {
        TokenKind k = cur().kind;
        if (k == TokenKind::LBRACE) {
            ++depth;
        } else if (k == TokenKind::RBRACE) {
            if (depth > 0 && --depth == 0) {
                advance();
                return;
            }
        } else if (depth == 0) {
            if (k == TokenKind::SEMI) {
                advance();
                return;
            }
            if (k == TokenKind::IDENT && at(1).kind == TokenKind::COLON) return;
        }
        advance();
    }
}
