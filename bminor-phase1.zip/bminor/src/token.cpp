#include "token.h"

const char* tokenKindName(TokenKind k) {
    switch (k) {
        case TokenKind::KW_ARRAY: return "KW_ARRAY";
        case TokenKind::KW_AUTO: return "KW_AUTO";
        case TokenKind::KW_BOOLEAN: return "KW_BOOLEAN";
        case TokenKind::KW_CHAR: return "KW_CHAR";
        case TokenKind::KW_ELSE: return "KW_ELSE";
        case TokenKind::KW_FALSE: return "KW_FALSE";
        case TokenKind::KW_FOR: return "KW_FOR";
        case TokenKind::KW_FUNCTION: return "KW_FUNCTION";
        case TokenKind::KW_IF: return "KW_IF";
        case TokenKind::KW_INTEGER: return "KW_INTEGER";
        case TokenKind::KW_PRINT: return "KW_PRINT";
        case TokenKind::KW_RETURN: return "KW_RETURN";
        case TokenKind::KW_STRING: return "KW_STRING";
        case TokenKind::KW_TRUE: return "KW_TRUE";
        case TokenKind::KW_VOID: return "KW_VOID";
        case TokenKind::KW_WHILE: return "KW_WHILE";
        case TokenKind::IDENT: return "IDENT";
        case TokenKind::INT_LIT: return "INT_LIT";
        case TokenKind::CHAR_LIT: return "CHAR_LIT";
        case TokenKind::STRING_LIT: return "STRING_LIT";
        case TokenKind::PLUS: return "PLUS";
        case TokenKind::MINUS: return "MINUS";
        case TokenKind::STAR: return "STAR";
        case TokenKind::SLASH: return "SLASH";
        case TokenKind::PERCENT: return "PERCENT";
        case TokenKind::CARET: return "CARET";
        case TokenKind::INC: return "INC";
        case TokenKind::DEC: return "DEC";
        case TokenKind::NOT: return "NOT";
        case TokenKind::AND: return "AND";
        case TokenKind::OR: return "OR";
        case TokenKind::LT: return "LT";
        case TokenKind::LE: return "LE";
        case TokenKind::GT: return "GT";
        case TokenKind::GE: return "GE";
        case TokenKind::EQ: return "EQ";
        case TokenKind::NE: return "NE";
        case TokenKind::ASSIGN: return "ASSIGN";
        case TokenKind::LPAREN: return "LPAREN";
        case TokenKind::RPAREN: return "RPAREN";
        case TokenKind::LBRACKET: return "LBRACKET";
        case TokenKind::RBRACKET: return "RBRACKET";
        case TokenKind::LBRACE: return "LBRACE";
        case TokenKind::RBRACE: return "RBRACE";
        case TokenKind::COMMA: return "COMMA";
        case TokenKind::SEMI: return "SEMI";
        case TokenKind::COLON: return "COLON";
        case TokenKind::COMMENT: return "COMMENT";
        case TokenKind::INVALID: return "INVALID";
        case TokenKind::END_OF_FILE: return "EOF";
    }
    return "?";
}

bool isKeyword(TokenKind k) { return k >= TokenKind::KW_ARRAY && k <= TokenKind::KW_WHILE; }

bool isTypeKeyword(TokenKind k) {
    switch (k) {
        case TokenKind::KW_ARRAY:
        case TokenKind::KW_AUTO:
        case TokenKind::KW_BOOLEAN:
        case TokenKind::KW_CHAR:
        case TokenKind::KW_INTEGER:
        case TokenKind::KW_STRING:
        case TokenKind::KW_VOID:
            return true;
        default:
            return false;
    }
}
