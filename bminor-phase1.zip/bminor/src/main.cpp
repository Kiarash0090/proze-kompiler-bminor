// bminor - B-Minor front end, phase 1: lexer, parser, AST and syntax highlighter.
#include <cstdlib>
#include <fstream>
#include <iostream>
#include <sstream>
#include <string>

#include "ast.h"
#include "common.h"
#include "highlighter.h"
#include "lexer.h"
#include "parser.h"

namespace {

void usage(std::ostream& os) {
    os << "Usage: bminor <input.bm> [options]\n"
          "  --ansi            print the highlighted source with ANSI colours (default)\n"
          "  --html <file>     write a standalone HTML/CSS page ('-' for stdout)\n"
          "  --tokens          dump the token stream\n"
          "  --ast             dump the abstract syntax tree\n"
          "  --no-highlight    do not print the highlighted source\n"
          "  --no-color        print the source without colour codes (same as NO_COLOR=1)\n"
          "  -h, --help        show this help\n"
          "Diagnostics go to stderr. Exit status: 0 ok, 1 lexical/syntax errors, 2 usage/IO error.\n";
}

std::string quote(const std::string& s) {
    std::string out = "'";
    for (char c : s) {
        if (c == '\n') out += "\\n";
        else if (c == '\r') out += "\\r";
        else if (c == '\t') out += "\\t";
        else out += c;
    }
    return out + "'";
}

}  // namespace

int main(int argc, char** argv) {
    std::string input, htmlPath;
    bool ansi = true, tokens = false, ast = false, color = std::getenv("NO_COLOR") == nullptr;

    for (int i = 1; i < argc; ++i) {
        std::string a = argv[i];
        if (a == "-h" || a == "--help") { usage(std::cout); return 0; }
        else if (a == "--ansi") ansi = true;
        else if (a == "--no-highlight") ansi = false;
        else if (a == "--no-color") color = false;
        else if (a == "--tokens") tokens = true;
        else if (a == "--ast") ast = true;
        else if (a == "--html") {
            if (i + 1 >= argc) { std::cerr << "bminor: --html needs a file name\n"; return 2; }
            htmlPath = argv[++i];
        } else if (!a.empty() && a[0] == '-') {
            std::cerr << "bminor: unknown option '" << a << "'\n";
            usage(std::cerr);
            return 2;
        } else if (input.empty()) input = a;
        else { std::cerr << "bminor: only one input file is supported\n"; return 2; }
    }
    if (input.empty()) { usage(std::cerr); return 2; }

    std::ifstream in(input, std::ios::binary);
    if (!in) { std::cerr << "bminor: cannot open '" << input << "'\n"; return 2; }
    std::stringstream buf;
    buf << in.rdbuf();
    const std::string source = buf.str();

    DiagnosticSink diag(input);
    Lexer lexer(source, diag);
    std::vector<Token> toks = lexer.tokenize();
    Parser parser(toks, diag);
    NodePtr tree = parser.parseProgram();

    if (tokens) {
        for (const Token& t : toks)
            std::cout << t.loc.line << ':' << t.loc.col << '\t' << tokenKindName(t.kind) << '\t' << quote(t.lexeme) << '\n';
    }
    if (ast) dumpAst(*tree, std::cout);

    Highlighter hl(source, toks, *tree);
    if (!htmlPath.empty()) {
        std::string html = hl.renderHtml("B-Minor: " + input);
        if (htmlPath == "-") std::cout << html;
        else {
            std::ofstream out(htmlPath, std::ios::binary);
            if (!out) { std::cerr << "bminor: cannot write '" << htmlPath << "'\n"; return 2; }
            out << html;
        }
    }
    if (ansi && !tokens && !ast && htmlPath != "-") {
        if (color) std::cout << hl.renderAnsi();
        else std::cout << source;
    }

    diag.print(std::cerr);
    if (diag.count() > 0) {
        std::cerr << diag.count() << (diag.count() == 1 ? " error" : " errors") << " found\n";
        return 1;
    }
    return 0;
}
