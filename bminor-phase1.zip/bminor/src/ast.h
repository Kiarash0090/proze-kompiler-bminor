// ast.h - abstract syntax tree for B-Minor.
//
// One generic Node type with a `kind` tag keeps the tree easy to build, walk
// and print. The layout of `kids` for every kind is documented below.
#pragma once
#include <iosfwd>
#include <memory>
#include <string>
#include <vector>

#include "common.h"

enum class NodeKind {
    Program,      // kids: declarations (VarDecl | FuncDecl | ErrorNode)*
    VarDecl,      // text: name | kids: type, [initializer]
    FuncDecl,     // text: name | kids: return type, ParamList, [Block]  (no Block = prototype)
    ParamList,    // kids: Param*
    Param,        // text: name | kids: type
    TypeSpec,     // text: integer | boolean | char | string | void | auto
    ArrayType,    // kids: element type, [size expression]
    Block,        // kids: statements
    ExprStmt,     // kids: expression
    ReturnStmt,   // kids: [expression]
    PrintStmt,    // kids: expression*
    IfStmt,       // kids: condition, then, [else]
    ForStmt,      // kids: init, condition, step, body (missing clauses are Empty)
    Empty,        // placeholder for an omitted for-clause
    AssignExpr,   // kids: target, value
    BinaryExpr,   // text: operator | kids: lhs, rhs
    UnaryExpr,    // text: - or ! | kids: operand
    PostfixExpr,  // text: ++ or -- | kids: operand
    CallExpr,     // kids: callee, arguments*
    IndexExpr,    // kids: array expression, index
    Identifier,   // text: name
    IntLiteral,   // text: lexeme
    CharLiteral,  // text: lexeme
    StringLiteral,// text: lexeme
    BoolLiteral,  // text: true | false
    ArrayInit,    // kids: elements (expressions or nested ArrayInit)
    ErrorNode     // stands in for a construct skipped during error recovery
};

struct Node;
using NodePtr = std::unique_ptr<Node>;

struct Node {
    NodeKind kind = NodeKind::ErrorNode;
    SourceLoc loc;            // line/column of the node's first token
    int tok = -1;             // index (in the full token vector) of the token that names/defines the node
    std::string text;         // name, operator or literal lexeme (see NodeKind)
    std::string typeAnn;      // type annotation; empty = not yet computed (filled by semantic analysis)
    std::vector<NodePtr> kids;

    Node* add(NodePtr child) {
        kids.push_back(std::move(child));
        return kids.back().get();
    }
};

const char* nodeKindName(NodeKind k);

// Indented tree dump, one node per line: Kind 'text' @line:col
void dumpAst(const Node& n, std::ostream& os, int depth = 0);
