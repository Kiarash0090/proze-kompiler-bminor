#include "highlighter.h"

namespace {

// SGR parameters for each category ("" = leave uncoloured).
const char* ansiCode(Category c) {
    switch (c) {
        case Category::Keyword: return "1;35";   // bold magenta
        case Category::TypeName: return "36";    // cyan
        case Category::Number: return "33";      // yellow
        case Category::Boolean: return "1;33";   // bold yellow
        case Category::Text: return "32";        // green
        case Category::Comment: return "90";     // grey
        case Category::FuncDecl: return "1;34";  // bold blue
        case Category::FuncCall: return "94";    // bright blue
        case Category::VarDecl: return "1;37";   // bold white
        case Category::Param: return "3;37";     // italic white
        case Category::Operator: return "31";    // red
        case Category::Invalid: return "97;41";  // white on red
        case Category::Variable:
        case Category::Punct:
        case Category::Plain: return "";
    }
    return "";
}

// CSS class list for each category ("" = no <span>).
const char* htmlClass(Category c) {
    switch (c) {
        case Category::Keyword: return "kw";
        case Category::TypeName: return "type";
        case Category::Number: return "lit num";
        case Category::Boolean: return "lit bool";
        case Category::Text: return "lit str";
        case Category::Comment: return "com";
        case Category::FuncDecl: return "fn-decl";
        case Category::FuncCall: return "fn-call";
        case Category::VarDecl: return "var-decl";
        case Category::Variable: return "var";
        case Category::Param: return "param";
        case Category::Operator: return "op";
        case Category::Punct: return "punct";
        case Category::Invalid: return "err";
        case Category::Plain: return "";
    }
    return "";
}

// Colour each line of `text` separately so a multi-line token (block comment)
// does not leak colour across the newline in terminals.
std::string paintAnsi(Category c, const std::string& text) {
    std::string code = ansiCode(c);
    if (code.empty()) return text;
    std::string out;
    size_t i = 0;
    while (i < text.size()) {
        size_t nl = text.find('\n', i);
        size_t end = nl == std::string::npos ? text.size() : nl;
        if (end > i) out += "\x1b[" + code + "m" + text.substr(i, end - i) + "\x1b[0m";
        if (nl == std::string::npos) break;
        out += '\n';
        i = nl + 1;
    }
    return out;
}

std::string escapeHtml(const std::string& s) {
    std::string out;
    for (char ch : s) {
        switch (ch) {
            case '&': out += "&amp;"; break;
            case '<': out += "&lt;"; break;
            case '>': out += "&gt;"; break;
            case '"': out += "&quot;"; break;
            default: out += ch;
        }
    }
    return out;
}

const char* kCss = R"(
  :root { color-scheme: light dark; --bg:#fbfbfd; --fg:#24292f; --kw:#8250df; --type:#0a7d8c; --lit:#9a6700;
          --str:#1a7f37; --com:#6e7781; --fn:#0550ae; --call:#0969da; --decl:#24292f; --op:#cf222e; }
  @media (prefers-color-scheme: dark) {
    :root { --bg:#0d1117; --fg:#c9d1d9; --kw:#d2a8ff; --type:#76e3ea; --lit:#e3b341; --str:#7ee787;
            --com:#8b949e; --fn:#79c0ff; --call:#a5d6ff; --decl:#f0f6fc; --op:#ff7b72; }
  }
  body { background: var(--bg); color: var(--fg); margin: 0; padding: 1.5rem; font-family: system-ui, sans-serif; }
  h1 { font-size: 1rem; font-weight: 600; margin: 0 0 1rem; }
  pre { margin: 0; padding: 1rem 1.25rem; overflow-x: auto; border-radius: 8px;
        border: 1px solid color-mix(in srgb, var(--fg) 20%, transparent);
        font: 14px/1.5 ui-monospace, SFMono-Regular, Menlo, Consolas, monospace; tab-size: 4; }
  .kw { color: var(--kw); font-weight: 700; }
  .type { color: var(--type); }
  .lit.num, .lit.bool { color: var(--lit); }
  .lit.bool { font-weight: 700; }
  .lit.str { color: var(--str); }
  .com { color: var(--com); font-style: italic; }
  .fn-decl { color: var(--fn); font-weight: 700; }
  .fn-call { color: var(--call); }
  .var-decl { color: var(--decl); font-weight: 700; }
  .param { font-style: italic; }
  .op { color: var(--op); }
  .err { background: #cf222e; color: #fff; border-radius: 2px; }
)";

}  // namespace

Highlighter::Highlighter(const std::string& source, const std::vector<Token>& tokens, const Node& ast)
    : src_(source), toks_(tokens), cat_(tokens.size(), Category::Plain) {
    classifyByKind();
    refineFromAst(ast);
}

void Highlighter::set(int tok, Category c) {
    if (tok >= 0 && static_cast<size_t>(tok) < cat_.size()) cat_[static_cast<size_t>(tok)] = c;
}

void Highlighter::classifyByKind() {
    for (size_t i = 0; i < toks_.size(); ++i) {
        TokenKind k = toks_[i].kind;
        Category c = Category::Plain;
        if (k == TokenKind::KW_TRUE || k == TokenKind::KW_FALSE) c = Category::Boolean;
        else if (isTypeKeyword(k)) c = Category::TypeName;
        else if (isKeyword(k)) c = Category::Keyword;
        else if (k == TokenKind::INT_LIT) c = Category::Number;
        else if (k == TokenKind::CHAR_LIT || k == TokenKind::STRING_LIT) c = Category::Text;
        else if (k == TokenKind::COMMENT) c = Category::Comment;
        else if (k == TokenKind::INVALID) c = Category::Invalid;
        else if (k >= TokenKind::PLUS && k <= TokenKind::ASSIGN) c = Category::Operator;
        else if (k >= TokenKind::LPAREN && k <= TokenKind::COLON) c = Category::Punct;
        cat_[i] = c;  // IDENT stays Plain until the AST says what it is
    }
}

// Post-order walk: children are visited first, so a parent can override what
// its children decided (a CallExpr turns its callee Identifier into a call).
void Highlighter::refineFromAst(const Node& n) {
    for (const auto& k : n.kids) refineFromAst(*k);
    switch (n.kind) {
        case NodeKind::FuncDecl: set(n.tok, Category::FuncDecl); break;
        case NodeKind::VarDecl: set(n.tok, Category::VarDecl); break;
        case NodeKind::Param: set(n.tok, Category::Param); break;
        case NodeKind::Identifier: set(n.tok, Category::Variable); break;
        case NodeKind::CallExpr:
            if (!n.kids.empty() && n.kids[0]->kind == NodeKind::Identifier) set(n.kids[0]->tok, Category::FuncCall);
            break;
        default: break;
    }
}

std::string Highlighter::renderAnsi() const {
    std::string out;
    size_t pos = 0;
    for (size_t i = 0; i < toks_.size(); ++i) {
        const Token& t = toks_[i];
        if (t.kind == TokenKind::END_OF_FILE) break;
        out += src_.substr(pos, t.offset - pos);  // whitespace between tokens, verbatim
        out += paintAnsi(cat_[i], t.lexeme);
        pos = t.offset + t.length;
    }
    out += src_.substr(pos);
    return out;
}

std::string Highlighter::renderHtml(const std::string& title) const {
    std::string body;
    size_t pos = 0;
    for (size_t i = 0; i < toks_.size(); ++i) {
        const Token& t = toks_[i];
        if (t.kind == TokenKind::END_OF_FILE) break;
        body += escapeHtml(src_.substr(pos, t.offset - pos));
        std::string cls = htmlClass(cat_[i]);
        if (cls.empty()) body += escapeHtml(t.lexeme);
        else body += "<span class=\"" + cls + "\">" + escapeHtml(t.lexeme) + "</span>";
        pos = t.offset + t.length;
    }
    body += escapeHtml(src_.substr(pos));

    std::string html = "<!DOCTYPE html>\n<html lang=\"en\">\n<head>\n<meta charset=\"utf-8\">\n";
    html += "<meta name=\"viewport\" content=\"width=device-width, initial-scale=1\">\n";
    html += "<title>" + escapeHtml(title) + "</title>\n<style>" + kCss + "</style>\n</head>\n<body>\n";
    html += "<h1>" + escapeHtml(title) + "</h1>\n<pre><code>" + body + "</code></pre>\n</body>\n</html>\n";
    return html;
}
