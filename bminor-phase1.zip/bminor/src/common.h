// common.h - source locations and diagnostics shared by every compiler phase.
#pragma once
#include <iosfwd>
#include <string>
#include <vector>

// 1-based line and column. Columns count bytes (a tab is one column).
struct SourceLoc {
    int line = 1;
    int col = 1;
};

struct Diagnostic {
    std::string file;
    SourceLoc loc;
    std::string message;
};

// Collects errors from all phases so that no phase has to stop on bad input.
class DiagnosticSink {
public:
    explicit DiagnosticSink(std::string file) : file_(std::move(file)) {}

    void error(SourceLoc loc, std::string message);
    size_t count() const { return diags_.size(); }
    const std::vector<Diagnostic>& all() const { return diags_; }

    // Prints "file:line:col: error: message", ordered by position.
    void print(std::ostream& os) const;

private:
    std::string file_;
    std::vector<Diagnostic> diags_;
};
