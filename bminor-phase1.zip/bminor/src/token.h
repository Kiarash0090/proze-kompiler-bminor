// token.h - token kinds and the Token record produced by the lexer.
#pragma once
#include <string>

#include "common.h"

enum class TokenKind {
    // Keywords (contiguous: isKeyword relies on the range)
    KW_ARRAY, KW_AUTO, KW_BOOLEAN, KW_CHAR, KW_ELSE, KW_FALSE, KW_FOR, KW_FUNCTION,
    KW_IF, KW_INTEGER, KW_PRINT, KW_RETURN, KW_STRING, KW_TRUE, KW_VOID, KW_WHILE,
    // Identifiers and literals
    IDENT, INT_LIT, CHAR_LIT, STRING_LIT,
    // Operators
    PLUS, MINUS, STAR, SLASH, PERCENT, CARET, INC, DEC, NOT, AND, OR,
    LT, LE, GT, GE, EQ, NE, ASSIGN,
    // Delimiters
    LPAREN, RPAREN, LBRACKET, RBRACKET, LBRACE, RBRACE, COMMA, SEMI, COLON,
    // Special
    COMMENT, INVALID, END_OF_FILE
};

struct Token {
    TokenKind kind = TokenKind::END_OF_FILE;
    std::string lexeme;   // exact source text
    SourceLoc loc;        // position of the first character
    size_t offset = 0;    // byte offset in the source
    size_t length = 0;    // byte length (== lexeme.size())
};

const char* tokenKindName(TokenKind k);
bool isKeyword(TokenKind k);
bool isTypeKeyword(TokenKind k);  // integer boolean char string void auto array
