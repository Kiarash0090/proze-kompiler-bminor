// parser.h - recursive-descent (LL) parser producing an AST.
#pragma once
#include <vector>

#include "ast.h"
#include "common.h"
#include "token.h"

// Strategy: top-down LL(1) with a single LL(2) decision (IDENT ':' starts a
// local declaration). Operator precedence is encoded as one loop per level,
// which is the standard way of removing left recursion from the expression
// grammar. See docs/grammar.md.
//
// Error handling is panic-mode: on a syntax error the parser reports one
// message, throws internally, and the nearest statement/declaration loop skips
// tokens up to a synchronisation point and carries on. The parser never
// aborts; it always returns a (possibly partial) tree.
class Parser {
public:
    // `tokens` is the full lexer output; Node::tok indexes into it. Comments are
    // skipped. INVALID tokens (already reported by the lexer) are not valid in any
    // rule, so they trigger recovery without a second diagnostic.
    Parser(const std::vector<Token>& tokens, DiagnosticSink& diag);

    NodePtr parseProgram();

private:
    struct ParseError {};  // internal control flow only

    const std::vector<Token>& all_;
    DiagnosticSink& diag_;
    std::vector<size_t> idx_;  // indices of the significant tokens
    size_t p_ = 0;             // cursor into idx_

    // token access
    const Token& cur() const { return all_[idx_[p_]]; }
    const Token& at(size_t ahead) const;
    size_t advance();
    bool match(TokenKind k);
    size_t expect(TokenKind k, const std::string& what);
    std::string describe(const Token& t) const;
    [[noreturn]] void fail(const std::string& msg);
    void report(const std::string& msg, SourceLoc loc);
    NodePtr node(NodeKind k, size_t tok, std::string text = "");

    // declarations and types
    NodePtr parseDecl();
    NodePtr parseFunctionRest(size_t nameTok);
    NodePtr parseParam();
    NodePtr parseType();
    NodePtr parseArrayInit();

    // statements
    NodePtr parseBlock();
    NodePtr parseStmt();
    NodePtr parseStmtSafe();
    NodePtr parseIf();
    NodePtr parseFor();
    NodePtr parseOptionalExpr(TokenKind terminator);

    // expressions (lowest to highest precedence)
    NodePtr parseExpr();
    NodePtr parseAssign();
    NodePtr parseBinary(size_t level);
    NodePtr parseExponent();
    NodePtr parseUnary();
    NodePtr parsePostfix();
    NodePtr parsePrimary();

    // error recovery
    void syncStmt(size_t start);
    void syncTopLevel(size_t start);
};
