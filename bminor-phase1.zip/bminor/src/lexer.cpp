#include "lexer.h"

#include <cstdio>
#include <unordered_map>

namespace {

const std::unordered_map<std::string, TokenKind> kKeywords = {
    {"array", TokenKind::KW_ARRAY},     {"auto", TokenKind::KW_AUTO},
    {"boolean", TokenKind::KW_BOOLEAN}, {"char", TokenKind::KW_CHAR},
    {"else", TokenKind::KW_ELSE},       {"false", TokenKind::KW_FALSE},
    {"for", TokenKind::KW_FOR},         {"function", TokenKind::KW_FUNCTION},
    {"if", TokenKind::KW_IF},           {"integer", TokenKind::KW_INTEGER},
    {"print", TokenKind::KW_PRINT},     {"return", TokenKind::KW_RETURN},
    {"string", TokenKind::KW_STRING},   {"true", TokenKind::KW_TRUE},
    {"void", TokenKind::KW_VOID},       {"while", TokenKind::KW_WHILE},
};

bool isIdentStart(char c) { return (c >= 'a' && c <= 'z') || (c >= 'A' && c <= 'Z') || c == '_'; }
bool isDigit(char c) { return c >= '0' && c <= '9'; }
bool isIdentPart(char c) { return isIdentStart(c) || isDigit(c); }
bool isHex(char c) { return isDigit(c) || (c >= 'a' && c <= 'f') || (c >= 'A' && c <= 'F'); }
bool isNonPrintable(char c) { return static_cast<unsigned char>(c) < 32 || c == 127; }

// 2^63 as decimal text: the largest integer literal we accept (so that
// -9223372036854775808 can still be written as unary minus applied to it).
const char* kMaxIntText = "9223372036854775808";

bool fitsInt64(const std::string& digits) {
    size_t i = 0;
    while (i + 1 < digits.size() && digits[i] == '0') ++i;  // strip leading zeros
    std::string d = digits.substr(i);
    if (d.size() != 19) return d.size() < 19;
    return d <= kMaxIntText;
}

}  // namespace

char Lexer::advance() {
    char c = src_[pos_++];
    if (c == '\n') {
        ++line_;
        col_ = 1;
    } else {
        ++col_;
    }
    return c;
}

Token Lexer::make(TokenKind kind, size_t start, SourceLoc loc) const {
    Token t;
    t.kind = kind;
    t.lexeme = src_.substr(start, pos_ - start);
    t.loc = loc;
    t.offset = start;
    t.length = pos_ - start;
    return t;
}

void Lexer::skipWhitespace() {
    while (!eof()) {
        char c = peek();
        if (c == ' ' || c == '\t' || c == '\n' || c == '\r') advance();
        else break;
    }
}

std::vector<Token> Lexer::tokenize() {
    std::vector<Token> tokens;
    while (true) {
        Token t = next();
        bool done = t.kind == TokenKind::END_OF_FILE;
        tokens.push_back(std::move(t));
        if (done) break;
    }
    return tokens;
}

// Dispatch on the first character; each scan* function then consumes the
// longest prefix that matches (maximal munch).
Token Lexer::next() {
    skipWhitespace();
    size_t start = pos_;
    SourceLoc loc = here();
    if (eof()) return make(TokenKind::END_OF_FILE, start, loc);

    char c = peek();
    if (isIdentStart(c)) return scanWord(start, loc);
    if (isDigit(c)) return scanNumber(start, loc);

    switch (c) {
        case '"': return scanString(start, loc);
        case '\'': return scanChar(start, loc);
        case '/':
            if (peek(1) == '/') return scanLineComment(start, loc);
            if (peek(1) == '*') return scanBlockComment(start, loc);
            advance();
            return make(TokenKind::SLASH, start, loc);
        case '+': return oneOrTwo(start, loc, '+', TokenKind::INC, TokenKind::PLUS);
        case '-': return oneOrTwo(start, loc, '-', TokenKind::DEC, TokenKind::MINUS);
        case '<': return oneOrTwo(start, loc, '=', TokenKind::LE, TokenKind::LT);
        case '>': return oneOrTwo(start, loc, '=', TokenKind::GE, TokenKind::GT);
        case '=': return oneOrTwo(start, loc, '=', TokenKind::EQ, TokenKind::ASSIGN);
        case '!': return oneOrTwo(start, loc, '=', TokenKind::NE, TokenKind::NOT);
        case '&':
            if (peek(1) == '&') { advance(); advance(); return make(TokenKind::AND, start, loc); }
            break;
        case '|':
            if (peek(1) == '|') { advance(); advance(); return make(TokenKind::OR, start, loc); }
            break;
        case '*': advance(); return make(TokenKind::STAR, start, loc);
        case '%': advance(); return make(TokenKind::PERCENT, start, loc);
        case '^': advance(); return make(TokenKind::CARET, start, loc);
        case '(': advance(); return make(TokenKind::LPAREN, start, loc);
        case ')': advance(); return make(TokenKind::RPAREN, start, loc);
        case '[': advance(); return make(TokenKind::LBRACKET, start, loc);
        case ']': advance(); return make(TokenKind::RBRACKET, start, loc);
        case '{': advance(); return make(TokenKind::LBRACE, start, loc);
        case '}': advance(); return make(TokenKind::RBRACE, start, loc);
        case ',': advance(); return make(TokenKind::COMMA, start, loc);
        case ';': advance(); return make(TokenKind::SEMI, start, loc);
        case ':': advance(); return make(TokenKind::COLON, start, loc);
        default: break;
    }
    return scanInvalid(start, loc);
}

Token Lexer::oneOrTwo(size_t start, SourceLoc loc, char second, TokenKind two, TokenKind one) {
    advance();
    if (!eof() && peek() == second) {
        advance();
        return make(two, start, loc);
    }
    return make(one, start, loc);
}

// Keyword-before-identifier: scan the whole word first (maximal munch), then
// look it up. "return" is a keyword, "returnx" is an identifier.
Token Lexer::scanWord(size_t start, SourceLoc loc) {
    while (!eof() && isIdentPart(peek())) advance();
    Token t = make(TokenKind::IDENT, start, loc);
    auto it = kKeywords.find(t.lexeme);
    if (it != kKeywords.end()) t.kind = it->second;
    return t;
}

Token Lexer::scanNumber(size_t start, SourceLoc loc) {
    while (!eof() && isDigit(peek())) advance();
    Token t = make(TokenKind::INT_LIT, start, loc);
    if (!fitsInt64(t.lexeme)) diag_.error(loc, "integer literal '" + t.lexeme + "' is out of range");
    return t;
}

// Consumes one escape sequence starting at a backslash. Returns false (after
// reporting) if it is not a valid B-Minor escape. Never consumes a newline.
bool Lexer::scanEscape() {
    SourceLoc loc = here();
    advance();  // the backslash
    if (eof()) {
        diag_.error(loc, "incomplete escape sequence at end of file");
        return false;
    }
    char c = peek();
    static const std::string simple = "abefnrtv\\'\"";
    if (!atEol() && simple.find(c) != std::string::npos) {
        advance();
        return true;
    }
    if (c == '0' && peek(1) == 'x' && isHex(peek(2)) && isHex(peek(3))) {
        for (int i = 0; i < 4; ++i) advance();
        return true;
    }
    if (!atEol()) advance();
    diag_.error(loc, "invalid escape sequence");
    return false;
}

Token Lexer::scanString(size_t start, SourceLoc loc) {
    advance();  // opening quote
    while (true) {
        if (eof() || atEol()) {
            diag_.error(loc, "unterminated string literal");
            return make(TokenKind::INVALID, start, loc);
        }
        char c = peek();
        if (c == '"') {
            advance();
            return make(TokenKind::STRING_LIT, start, loc);
        }
        if (c == '\\') {
            scanEscape();
            continue;
        }
        if (isNonPrintable(c)) diag_.error(here(), "non-printable character in string literal");
        advance();
    }
}

Token Lexer::scanChar(size_t start, SourceLoc loc) {
    advance();  // opening quote
    if (eof() || atEol()) {
        diag_.error(loc, "unterminated character literal");
        return make(TokenKind::INVALID, start, loc);
    }
    if (peek() == '\'') {
        advance();
        diag_.error(loc, "empty character literal");
        return make(TokenKind::INVALID, start, loc);
    }
    if (peek() == '\\') {
        scanEscape();
    } else {
        if (isNonPrintable(peek())) diag_.error(here(), "non-printable character in character literal");
        advance();
    }
    if (!eof() && peek() == '\'') {
        advance();
        return make(TokenKind::CHAR_LIT, start, loc);
    }
    // More than one character (or missing closing quote): skip to the closing
    // quote on this line if there is one, so we do not cascade errors.
    while (!eof() && !atEol() && peek() != '\'') advance();
    if (!eof() && peek() == '\'') {
        advance();
        diag_.error(loc, "character literal must contain exactly one character");
    } else {
        diag_.error(loc, "unterminated character literal");
    }
    return make(TokenKind::INVALID, start, loc);
}

Token Lexer::scanLineComment(size_t start, SourceLoc loc) {
    while (!eof() && !atEol()) advance();
    return make(TokenKind::COMMENT, start, loc);
}

Token Lexer::scanBlockComment(size_t start, SourceLoc loc) {
    advance();
    advance();  // "/*"
    while (!eof()) {
        if (peek() == '*' && peek(1) == '/') {
            advance();
            advance();
            return make(TokenKind::COMMENT, start, loc);
        }
        advance();
    }
    diag_.error(loc, "unterminated block comment");
    return make(TokenKind::INVALID, start, loc);
}

// Unknown character: report it, skip it (a whole UTF-8 sequence counts as
// one), and let the caller continue with the next token.
Token Lexer::scanInvalid(size_t start, SourceLoc loc) {
    unsigned char c = static_cast<unsigned char>(peek());
    advance();
    if (c >= 0x80)
        while (!eof() && (static_cast<unsigned char>(peek()) & 0xC0) == 0x80) advance();
    Token t = make(TokenKind::INVALID, start, loc);
    std::string shown = t.lexeme;
    if (c < 32 || c == 127) {
        char buf[8];
        std::snprintf(buf, sizeof buf, "\\x%02X", c);
        shown = buf;
    }
    std::string msg = "invalid character '" + shown + "'";
    if (c == '&') msg += " (did you mean '&&'?)";
    if (c == '|') msg += " (did you mean '||'?)";
    diag_.error(loc, msg);
    return t;
}
