// highlighter.h - AST-driven syntax highlighting (ANSI terminal and HTML/CSS).
#pragma once
#include <string>
#include <vector>

#include "ast.h"
#include "token.h"

enum class Category {
    Plain, Keyword, TypeName, Number, Boolean, Text, Comment,
    FuncDecl, FuncCall, VarDecl, Variable, Param, Operator, Punct, Invalid
};

// Two-step colouring:
//   1. every token gets a default category from its kind (keyword, number, ...);
//   2. a walk over the AST refines identifiers using their syntactic role, which a
//      token stream alone cannot know (function name vs. call vs. variable vs. parameter).
// Output is reproduced byte-for-byte from the source; only colour markup is added.
class Highlighter {
public:
    // `ast` may be partial (after syntax errors); identifiers outside any
    // recognised construct simply stay uncoloured.
    Highlighter(const std::string& source, const std::vector<Token>& tokens, const Node& ast);

    std::string renderAnsi() const;
    std::string renderHtml(const std::string& title) const;

    Category categoryOf(size_t tokenIndex) const { return cat_[tokenIndex]; }

private:
    const std::string& src_;
    const std::vector<Token>& toks_;
    std::vector<Category> cat_;

    void classifyByKind();
    void refineFromAst(const Node& n);
    void set(int tok, Category c);
};
