#include <algorithm>
#include <ostream>

#include "common.h"

void DiagnosticSink::error(SourceLoc loc, std::string message) {
    diags_.push_back({file_, loc, std::move(message)});
}

void DiagnosticSink::print(std::ostream& os) const {
    std::vector<Diagnostic> sorted = diags_;
    std::stable_sort(sorted.begin(), sorted.end(), [](const Diagnostic& a, const Diagnostic& b) {
        if (a.loc.line != b.loc.line) return a.loc.line < b.loc.line;
        return a.loc.col < b.loc.col;
    });
    for (const auto& d : sorted)
        os << d.file << ':' << d.loc.line << ':' << d.loc.col << ": error: " << d.message << '\n';
}
