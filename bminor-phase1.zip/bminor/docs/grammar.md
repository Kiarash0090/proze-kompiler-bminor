# B-Minor grammar (Phase 1)

Parser strategy: **top-down LL(k), recursive descent**, one function per non-terminal
(`src/parser.cpp`). It is LL(1) everywhere except one LL(2) decision (section 4).

## 1. EBNF

Terminals are quoted or UPPER_CASE tokens. `{ x }` = zero or more, `[ x ]` = optional, `( a | b )` = choice.

```ebnf
program        = { decl } ;

decl           = IDENT ":" ( function-rest | type [ "=" initializer ] ";" ) ;
function-rest  = "function" type "(" [ param { "," param } ] ")" ( "=" block | ";" ) ;
param          = IDENT ":" type ;

type           = "integer" | "boolean" | "char" | "string" | "void" | "auto"
               | "array" "[" [ expr ] "]" type ;

initializer    = expr | init-list ;
init-list      = "{" ( expr | init-list ) { "," ( expr | init-list ) } "}" ;

block          = "{" { stmt } "}" ;
stmt           = block
               | "if" "(" expr ")" stmt [ "else" stmt ]
               | "for" "(" [ expr ] ";" [ expr ] ";" [ expr ] ")" stmt
               | "return" [ expr ] ";"
               | "print" [ expr { "," expr } ] ";"
               | decl                       (* starts with IDENT ":" *)
               | expr ";" ;

expr           = or [ "=" expr ] ;                      (* assignment, right-assoc *)
or             = and   { "||" and } ;
and            = cmp   { "&&" cmp } ;
cmp            = add   { ( "<" | "<=" | ">" | ">=" | "==" | "!=" ) add } ;
add            = mul   { ( "+" | "-" ) mul } ;
mul            = exp   { ( "*" | "/" | "%" ) exp } ;
exp            = unary [ "^" exp ] ;                    (* right-assoc *)
unary          = ( "-" | "!" ) unary | postfix ;
postfix        = primary { "[" expr "]" | "(" [ expr { "," expr } ] ")" | "++" | "--" } ;
primary        = INT_LIT | CHAR_LIT | STRING_LIT | "true" | "false" | IDENT | "(" expr ")" ;
```

Context-sensitive rules (assignment target must be a variable or element, only
names can be called, `void` only as a return type, type compatibility...) are
checked either in the parser when trivial (assignment target, callee) or in the
semantic phase (Phase 2). Comments are not part of the grammar; the parser skips `COMMENT` tokens.

## 2. Operator precedence (highest first)

| Level | Operators | Associativity | Grammar rule |
|---|---|---|---|
| 1 | `()` call, `[]` index, `++` `--` (postfix) | left | `postfix` |
| 2 | `-` `!` (unary) | right | `unary` |
| 3 | `^` | right | `exp` |
| 4 | `*` `/` `%` | left | `mul` |
| 5 | `+` `-` | left | `add` |
| 6 | `<` `<=` `>` `>=` `==` `!=` | left | `cmp` |
| 7 | `&&` | left | `and` |
| 8 | `\|\|` | left | `or` |
| 9 | `=` | right | `expr` |

## 3. Left recursion

The natural way to write a left-associative operator is left-recursive and
cannot be used by a recursive-descent parser (it would call itself forever):

```
add = add ( "+" | "-" ) mul | mul ;      (* left recursive: NOT LL *)
```

It is rewritten as an iteration, which accepts the same language:

```
add = mul { ( "+" | "-" ) mul } ;
```

The loop in `Parser::parseBinary` folds the operands to the left while looping,
so `a - b - c` still builds `(a - b) - c`. Every binary level (`or`, `and`,
`cmp`, `add`, `mul`) is handled by that one function with a table of operator
sets. `exp` and `expr` are *right*-recursive (`a ^ (b ^ c)`, `a = (b = c)`),
which is fine for LL parsing and gives the right associativity directly.
No other rule is left-recursive (checked by hand: every rule starts with a
terminal or with a non-terminal lower in the precedence chain).

## 4. FIRST / FOLLOW and the LL(1) check

| Non-terminal | FIRST |
|---|---|
| `decl` | `IDENT` |
| `type` | `integer boolean char string void auto array` |
| `expr` (and every level down to `primary`) | `-  !  (  IDENT  INT_LIT  CHAR_LIT  STRING_LIT  true  false` |
| `initializer` | FIRST(expr) ∪ `{` |
| `stmt` | `{  if  for  return  print` ∪ FIRST(expr) (`IDENT` is shared with `decl`) |

Decisions the parser makes with one token of look-ahead:

* After `IDENT ":"`: `function` vs a type: FIRST sets are disjoint.
* Initializer: `{` vs an expression: disjoint.
* Operator loops: continue only while the current token is in the level's operator set. None of those sets intersects FOLLOW(expr) = `; ) ] , }` or `=`, so the loop condition is unambiguous.
* Optional `[ expr ]` in `for`, `return`, `print`, array size and call arguments: take the expression when the token is not the terminator (`;`, `)`, `]`).

**The two places that are not plain LL(1):**

1. **Statement starting with `IDENT`**: a local declaration (`x: integer;`) or an expression (`x = 1;`). Looking at the *second* token resolves it, because `:` can never follow an identifier in an expression. This makes the parser LL(2) at that single point (`Parser::parseStmt`, `at(1)`).
2. **Dangling else**: `if (a) if (b) s1; else s2;`. `else` is in FOLLOW(stmt), so the grammar is ambiguous. We use the standard rule: `else` binds to the nearest unmatched `if`; the code simply consumes an `else` greedily right after parsing the inner statement.

## 5. AST

Node kinds and the layout of their children are listed in `src/ast.h`. Leaves are
literals and identifiers; internal nodes are `FuncDecl`, `IfStmt`, `BinaryExpr`,
`CallExpr`, `ReturnStmt`, ... Every node has `loc` (line and column of its first
token), `tok` (index of its defining token, used by the highlighter) and an empty
`typeAnn` field reserved for the semantic phase. Parentheses leave no node; they only
shape the tree.

## 6. Error recovery (panic mode)

On the first syntax error in a construct the parser reports **one** message,
unwinds (internal exception) to the nearest recovery loop and skips tokens to a
synchronisation point:

| Where | Skips until | Sync points |
|---|---|---|
| inside a block (`syncStmt`) | after the next `;`, or before the `}` closing the block | also stops at `if` `for` `return` `print` or `IDENT ":"` (next statement); a balanced `{ ... }` met on the way is skipped as one unit |
| at file level (`syncTopLevel`) | after the next `;` or after the `}` ending the broken declaration | also stops at `IDENT ":"` (next declaration) |

The offending statement/declaration becomes an `ErrorNode` and parsing resumes, so
one run reports many errors. At least one token is always consumed, so
recovery cannot loop forever. A missing closing `}` at end of file is reported once
with the line of the opening brace. `INVALID` tokens (already reported by the lexer)
trigger the same recovery silently, so one bad character never produces two messages.
