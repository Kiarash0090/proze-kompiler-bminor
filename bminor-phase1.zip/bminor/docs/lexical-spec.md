# B-Minor lexical specification (Phase 1)

Source: `src/lexer.cpp`. The scanner is a hand-written DFA: the first character
selects the start state, and each `scan*` function walks the transitions of
one token class while the next character keeps the match going (so it always
takes the **longest** match).

## 1. Token classes and regular expressions

Notation: `[...]` character class, `*` `+` `?` as usual, `\x20-\x7E` printable ASCII.

| Token | Regular expression | Notes |
|---|---|---|
| whitespace | `[ \t\r\n]+` | skipped, never a token |
| `COMMENT` (line) | `//[^\n]*` | stops before the line break |
| `COMMENT` (block) | `/\*([^*]\|\*+[^*/])*\*+/` | not nested; kept as a token for highlighting |
| `IDENT` | `[A-Za-z_][A-Za-z0-9_]*` | after matching, looked up in the keyword table |
| keywords | `array auto boolean char else false for function if integer print return string true void while` | `KW_*` tokens; `while` is reserved but B-Minor has no while loop |
| `INT_LIT` | `[0-9]+` | no sign: `-5` is `MINUS` then `INT_LIT`; value must be <= 2^63 |
| escape (inside literals) | `\\([abefnrtv\\'"]\|0x[0-9A-Fa-f]{2})` | |
| `CHAR_LIT` | `'([^'\\\x00-\x1F\x7F]\|ESC)'` | exactly one character or escape |
| `STRING_LIT` | `"([^"\\\x00-\x1F\x7F\n]\|ESC)*"` | no raw newline inside |
| `PLUS` `MINUS` `STAR` `SLASH` `PERCENT` `CARET` | `+ - * / % ^` | |
| `INC` `DEC` | `++ --` | |
| `NOT` `AND` `OR` | `! && \|\|` | |
| `LT` `LE` `GT` `GE` `EQ` `NE` | `< <= > >= == !=` | |
| `ASSIGN` | `=` | |
| delimiters | `( ) [ ] { } , ; :` | `LPAREN RPAREN LBRACKET RBRACKET LBRACE RBRACE COMMA SEMI COLON` |
| `INVALID` | anything else, plus malformed literals/comments | always accompanied by a diagnostic |

Every token records: type, exact lexeme, file (via the diagnostic sink), line, column (1-based, bytes) and byte offset/length.

## 2. Choosing between matching rules

When several rules can match at the current position the lexer applies, in order:

1. **Longest match (maximal munch).** `<=` is one token, never `<` `=`; `a+++b` is `a` `++` `+` `b`; `returnx` is one identifier; `12abc` is `12` then `abc`.
2. **Keyword before identifier.** An identifier-shaped word is scanned completely first, then compared with the keyword table. `return` becomes `KW_RETURN`, but `returnx` and `Return` stay `IDENT` (keywords are case-sensitive).
3. **Comment before operator.** `//` and `/*` win over `/`.
4. **First rule in the table wins on a tie of equal length** (not needed in B-Minor: the first character is enough to pick a unique class).

## 3. Lexical error handling

The lexer never throws and never stops. Each case adds one diagnostic and resumes right after the bad text:

| Situation | Token produced | Message |
|---|---|---|
| unknown character (`#`, `@`, `$`, a lone `&` or `\|`, any non-ASCII sequence) | `INVALID` (one per character; a UTF-8 sequence counts as one) | `invalid character 'X'` (with a hint for `&` and `\|`) |
| string with no closing quote before end of line/file | `INVALID` up to the line end | `unterminated string literal` |
| block comment with no `*/` | `INVALID` to end of file | `unterminated block comment` |
| empty `''`, more than one char `'ab'`, missing quote | `INVALID` | `empty character literal`, `character literal must contain exactly one character`, `unterminated character literal` |
| bad escape such as `\q` | literal is kept | `invalid escape sequence` (reported at the backslash) |
| control character inside a literal | literal is kept | `non-printable character in string literal` |
| integer larger than 2^63 | `INT_LIT` is kept | `integer literal '...' is out of range` |

`INVALID` tokens are skipped by the parser without a second message (see `docs/grammar.md`, section 6).
