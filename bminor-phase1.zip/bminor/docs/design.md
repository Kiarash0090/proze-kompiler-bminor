# Design notes (Phase 1)

## Pipeline

```
source text --Lexer--> tokens --Parser--> AST --Highlighter--> ANSI / HTML
                 \__ diagnostics (DiagnosticSink) shared by all stages __/
```

| Module | Files | Responsibility |
|---|---|---|
| diagnostics | `common.h`, `diagnostics.cpp` | `SourceLoc`, error collection, `file:line:col: error:` printing |
| tokens | `token.h/.cpp` | `TokenKind`, `Token` (type, lexeme, line, column, offset) |
| lexer | `lexer.h/.cpp` | characters to tokens, maximal munch, keyword table, lexical errors |
| AST | `ast.h/.cpp` | `Node` / `NodeKind`, tree dump |
| parser | `parser.h/.cpp` | recursive descent, precedence, AST construction, panic-mode recovery |
| highlighter | `highlighter.h/.cpp` | token categories + AST refinement, ANSI and HTML renderers |
| driver | `main.cpp` | command line, I/O, exit status |

Each stage depends only on the one before it (the highlighter needs tokens + AST),
so a later phase (symbol table, type checker) can be added between parser and
highlighter without touching the lexer or parser.

## Decisions and why

* **Lexer: hand-written DFA, not `std::regex`.** Gives exact control over maximal munch,
  precise positions, and error tokens; the regular expressions are documented in `docs/lexical-spec.md`.
* **Comments are tokens.** The lexer keeps them so the highlighter can print them and
  the output can reproduce the source exactly; the parser filters them out.
* **Whitespace is not a token.** The highlighter copies the bytes between tokens
  (using each token's byte offset), which guarantees that stripping the colour codes returns the
  original file. This property is unit-tested, also on broken input.
* **One generic `Node` with a kind tag.** Small, easy to walk and print. `tok` points back into the
  token vector, so the highlighter can colour exactly the token that names a declaration or a call.
  `typeAnn` is already there (empty) for the semantic phase.
* **Recursive descent + one loop per precedence level.** Direct mapping from grammar to code, easy to
  explain and to recover from errors in. See `docs/grammar.md`.
* **Errors never stop the run.** Lexer: `INVALID` tokens. Parser: panic mode with `ErrorNode`s.
  Diagnostics are sorted by position when printed. Exit status is 1 when any error was reported.

## AST-based highlighting (why not regex)

A token stream cannot tell `f` in `f(x)` from `f` in `y = f;`, or a parameter from a local variable. The
highlighter therefore works in two steps:

1. Default category from the token kind: keyword, type keyword, number, boolean, string/char, comment, operator, punctuation, invalid.
2. Post-order walk of the AST that refines identifiers by role:
   `FuncDecl` name → function declaration, `CallExpr` callee → function call, `Param` → parameter,
   `VarDecl` → variable declaration, any other `Identifier` → variable.
   (Post-order matters: the callee `Identifier` is first marked "variable", then its parent `CallExpr` overrides it.)

With a symbol table in Phase 2 the same walk can also separate locals, globals and parameters at *use* sites.

| Category | ANSI | HTML class |
|---|---|---|
| keyword | bold magenta | `kw` |
| type name | cyan | `type` |
| number / boolean | yellow | `lit num` / `lit bool` |
| string / char | green | `lit str` |
| comment | grey | `com` |
| function declaration | bold blue | `fn-decl` |
| function call | bright blue | `fn-call` |
| variable declaration | bold white | `var-decl` |
| variable use | default | `var` |
| parameter | italic | `param` |
| operator | red | `op` |
| invalid token | white on red | `err` |

HTML output is a standalone page (embedded CSS, light and dark theme, no JavaScript) with a `<pre><code>` block.

## Testing

* `tests/unit_tests.cpp`: 100+ checks: keyword priority, maximal munch, comment and position tracking,
  every lexical error, precedence/associativity, dangling else, AST shape and locations, error recovery,
  never-crash inputs, highlighter roles, the colour-stripping round trip, HTML structure.
* `tests/valid/*.bm`: programs that must produce no diagnostics. `tests/invalid/*.bm`: programs that must exit
  with status 1, print the expected message and the expected *number* of errors (`// EXPECT:` and `// ERRORS:` headers).
* The code was also run under AddressSanitizer/UBSan against 1500 randomly mutated programs without a crash or hang.

Run everything with `make test`.

## Known limits (Phase 1)

* No semantic analysis: undeclared names, type errors, `void` misuse and duplicate declarations are not reported yet.
* `while`, `float`, `carray` and similar additions from other years' B-Minor editions are not part of this
  grammar (`while` is a reserved word and is reported as unsupported). Add a keyword to the table in `lexer.cpp`
  and a rule in `parser.cpp` to extend the language.
* Columns count bytes, not Unicode characters.
